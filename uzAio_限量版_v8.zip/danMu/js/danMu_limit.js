// ignore
//@name:限量版弹幕
//@version:8
//@remark:以豆儿弹幕接口为主源的全新扩展。首次自动匹配后会记住番剧，切集自动沿同一部番（多键匹配，站点名与弹幕番名不一致也能跟）；支持设置里手动指定番剧ID/番名，带防误跟、跨季补集、多线路聚合、刷屏抑制、屏蔽词正则、条数上限、集数/时间偏移、时间窗裁剪、缓存
//@env:弹幕接口地址##自己填的弹幕源都放这里：支持 名称@地址 或纯地址，多条用 | 或 ; 或换行分隔；地址型（?ac=dm&url=）与豆儿/弹弹Play 接口型（含 /api/v1/xxx 令牌路径）都认；采集站地址会自动拿去当找片兜底。留空用内置线路
//@env:锁定跟随##填 1 开启、0 关闭，默认开启。开启后手动选过的线路会跟着集数往下走
//@env:指定线路##手动指定默认使用的线路名（对应线路列表里的名字），留空=智能。客户端不支持手动选线路时用这个
//@env:屏蔽词##用 | 分隔，命中的弹幕丢弃；支持正则写法 /关键词1|关键词2/ ，例如 公众号|加群|/群号[0-9]{5,}/
//@env:高级设置##用 ; 分隔：id=15632 手动指定番剧ID（弹弹Play的animeId）｜lockname=番剧名 手动指定番名｜ep0=1 站点第1集对应弹幕第几集｜epoff=+1 集数偏移｜max=3000 条数上限｜timeoff=2 时间偏移秒｜to=12000 超时毫秒｜conc=3 并发｜dedup=strong 严格去重｜clip=60-1200 只留该时段｜filter=0 关低质过滤｜label=1 标注来源｜agg=0 关聚合｜order=虾米,弹弹Play 线路顺序｜alias=灵笼=灵笼:INCARNATION 剧名别名｜spoiler=剧透词｜clear=1 清除锁定
//@order: A01
// ignore

import {} from '../../core/uz3lib.js'
import {} from '../../core/uzUtils.js'

const appConfig = {
    _uzTag: '',
    get uzTag() {
        return this._uzTag
    },
    set uzTag(value) {
        this._uzTag = value
    }
}

class DanMu {
    constructor() {
        this.content = ''
        this.time = 0
    }
}

class BackData {
    constructor() {
        this.data = []
        this.error = ''
    }
}

// ============ 内置线路 ============
var builtinUrlLines = [
    { name: '虾米', url: 'https://dmku.hls.one/?ac=dm&url=' },
    { name: 'DouFun', url: 'https://danmu.56uxi.com/?ac=dm&url=' },
    { name: '弹幕库', url: 'https://api.danmu.icu/?ac=dm&url=' },
    { name: '678弹幕', url: 'https://se.678.ooo/?ac=dm&url=' }
]
var builtinApiBases = [
    { name: '豆儿', base: 'https://dm.qqkart.me' },
    { name: '豆儿备用', base: 'https://dmk.abai.ccwu.cc/api/v1/abaibai' },
    { name: '弹弹Play', base: 'https://api.danmaku.weeblify.app/ddp/v1?path=' }
]
// 采集站（2026-11 实测可用，均返回 vod_play_url）
var caiJi = ['https://api.ffzyapi.com/api.php/provide/vod', 'https://api.ukuapi.com/api.php/provide/vod']

// 内置常见别名（片名 → 弹弹Play 收录名）
var builtinAlias = {
    灵笼: '灵笼: INCARNATION',
    斗罗大陆: '斗罗大陆',
    斗罗大陆2绝世唐门: '斗罗大陆2绝世唐门',
    凡人修仙传: '凡人修仙传',
    完美世界: '完美世界',
    吞噬星空: '吞噬星空',
    遮天: '遮天',
    仙逆: '仙逆',
    剑来: '剑来',
    斗破苍穹: '斗破苍穹',
    神印王座: '神印王座',
    沧元图: '沧元图',
    一人之下: '一人之下',
    时光代理人: '时光代理人'
}

var LOCK_KEY = '限量版锁定'
var HEALTH_KEY = '限量版线路健康度'
var MAX_LOCK = 20
var MEMO_MAX = 60
var memo = {}

// ============ 片名处理 ============
var QUALITY_WORDS = /[\(（\[【]?(?:国语|粤语|双语|中字|中文字幕|简中|繁中|高清|超清|蓝光|完整版|未删减|无删减|HD|BD|TC|TS|WEB[- ]?DL|4K|8K|1080P|2160P|720P|60帧|HDR)[\)）\]】]?/gi

function isUrlLine(u) {
    return /[?&]ac=dm|url=$/.test(u)
}

function epNum(args) {
    let ep = String(args.episode || '').trim()
    let n = parseInt(ep.replace(/[^\d]/g, ''), 10)
    if (!n || isNaN(n)) {
        const m = String(args.name || '').match(/第\s*([0-9]+)\s*[集话期回]/)
        if (m) n = parseInt(m[1], 10)
    }
    if (!n || isNaN(n)) n = 1
    return n
}

function seasonNum(str) {
    const s = String(str || '')
    let m = s.match(/第\s*([0-9一二三四五六七八九十]+)\s*季/)
    if (m) {
        const cn = { 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 }
        const v = cn[m[1]] || parseInt(m[1], 10) || 1
        return v
    }
    m = s.match(/[Ss](\d{1,2})[Ee]\d{1,3}/)
    if (m) return parseInt(m[1], 10) || 1
    m = s.match(/[Ss]eason\s*(\d{1,2})/i)
    if (m) return parseInt(m[1], 10) || 1
    m = s.match(/[Ss](\d{1,2})/)
    if (m) return parseInt(m[1], 10) || 1
    return 0
}

function cleanName(name) {
    let t = String(name || '').trim()
    t = t.replace(QUALITY_WORDS, '')
    t = t.replace(/第\s*[0-9]+\s*[集话期回]/g, '')
    t = t.replace(/[Ss]\d{1,2}[Ee]\d{1,3}/g, '')
    t = t.replace(/[Ee][Pp]?\s*[0-9]{1,3}$/g, '')
    t = t.replace(/[\(（\[【].*?[\)）\]】]/g, '')
    t = t.replace(/[\s·]+/g, ' ')
    t = t.replace(/[：:\-—_]+$/g, '')
    return t.trim()
}

function titleKey(args) {
    return cleanName(args.name).replace(/[：:]+\s*$/g, '').trim()
}

function normName(s) {
    return String(s || '')
        .toLowerCase()
        .replace(/[\s:：·,，.。\-—_(){}\[\]【】!！?？'"“”]/g, '')
}

// 相似度（字二元组 Dice），用于防误跟
function similar(a, b) {
    const A = normName(a)
    const B = normName(b)
    if (!A || !B) return 0
    if (A === B) return 1
    if (A.length < 2 || B.length < 2) return A.indexOf(B) >= 0 || B.indexOf(A) >= 0 ? 0.5 : 0
    const grams = (s) => {
        const g = {}
        for (let i = 0; i < s.length - 1; i++) g[s.substr(i, 2)] = 1
        return g
    }
    const ga = grams(A)
    const gb = grams(B)
    let hit = 0
    let total = 0
    Object.keys(ga).forEach((k) => {
        total++
        if (gb[k]) hit++
    })
    Object.keys(gb).forEach((k) => {
        if (!ga[k]) total++
    })
    return total === 0 ? 0 : (2 * hit) / total
}

// ============ 配置 ============
async function loadConfig() {
    const cfg = {
        urlLines: builtinUrlLines.slice(),
        apiBases: builtinApiBases.slice(),
        follow: true,
        block: [],
        spoiler: [],
        regBlock: [],
        epOff: 0,
        max: 3000,
        timeOff: 0,
        timeout: 8000,
        conc: 3,
        strongDedup: false,
        clip: null,
        lowFilter: true,
        label: false,
        agg: true,
        order: [],
        alias: {},
        lockName: '',
        lineHint: '',
        forceId: 0,
        ep0: 0,
        clear: false,
        movie: false
    }
    try {
        const raw = await getEnv(appConfig.uzTag, '弹幕接口地址')
        if (raw && raw.trim().length > 0) {
            // 用户自己填的源：支持 | ; 换行 逗号 分隔；支持 名称@地址 或 纯地址
            const items = raw
                .split(/[|;\n\r]+/)
                .map((s) => s.trim())
                .filter((s) => s.length > 0)
            items.forEach((item, i) => {
                let name = '我的线路' + (i + 1)
                let url = item
                const pos = item.indexOf('@')
                if (pos >= 0) {
                    const n = item.slice(0, pos).trim()
                    if (n.length > 0) name = n
                    url = item.slice(pos + 1).trim()
                }
                if (!/^https?:\/\//i.test(url)) return
                url = url.replace(/[，,。\s]+$/g, '')
                // 采集站（苹果CMS/资源站）不是弹幕接口，拿来做“找视频地址”的兜底
                if (/provide\/vod/i.test(url) || /api\.php/i.test(url)) {
                    if (caiJi.indexOf(url) < 0) caiJi.push(url)
                    return
                }
                if (isUrlLine(url)) {
                    cfg.urlLines.push({ name: name, url: url })
                } else {
                    cfg.apiBases.push({ name: name, base: url.replace(/\/+$/, '') })
                }
            })
        }
    } catch (e) {}
    try {
        if (String(await getEnv(appConfig.uzTag, '锁定跟随')).trim() === '0') cfg.follow = false
    } catch (e) {}
    try {
        const lh = String(await getEnv(appConfig.uzTag, '指定线路')).trim()
        if (lh && lh !== '智能') cfg.lineHint = lh
    } catch (e) {}
    try {
        const b = await getEnv(appConfig.uzTag, '屏蔽词')
        if (b && b.trim().length > 0) {
            b.split('|')
                .map((x) => x.trim())
                .filter((x) => x.length > 0)
                .forEach((w) => {
                    if (w.length > 1 && w[0] === '/' && w[1] !== '/') {
                        try {
                            cfg.regBlock.push(new RegExp(w.slice(1), 'i'))
                        } catch (e) {}
                    } else cfg.block.push(w)
                })
        }
    } catch (e) {}
    try {
        const adv = await getEnv(appConfig.uzTag, '高级设置')
        if (adv && adv.trim().length > 0) {
            adv.split(';').forEach((pair) => {
                const eq = pair.indexOf('=')
                if (eq < 0) return
                const k = pair.slice(0, eq).trim().toLowerCase()
                const v = pair.slice(eq + 1).trim()
                if (k === 'epoff') cfg.epOff = parseInt(v, 10) || 0
                if (k === 'max') cfg.max = Math.max(100, parseInt(v, 10) || 3000)
                if (k === 'timeoff') cfg.timeOff = parseFloat(v) || 0
                if (k === 'to') cfg.timeout = Math.min(30000, Math.max(3000, parseInt(v, 10) || 12000))
                if (k === 'conc') cfg.conc = Math.min(6, Math.max(1, parseInt(v, 10) || 3))
                if (k === 'dedup') cfg.strongDedup = v.toLowerCase() === 'strong'
                if (k === 'filter') cfg.lowFilter = !(v === '0' || v.toLowerCase() === 'false')
                if (k === 'label') cfg.label = v === '1' || v.toLowerCase() === 'true'
                if (k === 'agg') cfg.agg = !(v === '0' || v.toLowerCase() === 'false')
                if (k === 'clear') cfg.clear = v === '1' || v.toLowerCase() === 'true'
                if (k === 'id') cfg.forceId = parseInt(v.replace(/[^\d]/g, ''), 10) || 0
                if (k === 'ep0') cfg.ep0 = parseInt(v, 10) || 0
                if (k === 'lockname') cfg.lockName = v
                if (k === 'order') cfg.order = v.split(',').map((x) => x.trim()).filter((x) => x.length > 0)
                if (k === 'spoiler') cfg.spoiler = v.split('|').map((x) => x.trim()).filter((x) => x.length > 0)
                if (k === 'clip') {
                    const parts = v.split('-')
                    if (parts.length === 2) {
                        const s = parseFloat(parts[0]) || 0
                        const e = parseFloat(parts[1]) || 0
                        if (e > s) cfg.clip = [s, e]
                    }
                }
                if (k === 'alias') {
                    v.split('|').forEach((kv) => {
                        const a = kv.split('=')
                        if (a.length >= 2) cfg.alias[normName(a[0])] = a.slice(1).join('=').trim()
                    })
                }
            })
        }
    } catch (e) {}
    // 内置别名兜底
    Object.keys(builtinAlias).forEach((k) => {
        if (!cfg.alias[normName(k)]) cfg.alias[normName(k)] = builtinAlias[k]
    })
    return cfg
}

// ============ 锁定 & 健康度 ============
async function readJsonEnv(key) {
    try {
        const raw = await getEnv(appConfig.uzTag, key)
        if (!raw) return {}
        const j = JSON.parse(raw)
        return j && typeof j === 'object' ? j : {}
    } catch (e) {
        return {}
    }
}

async function writeJsonEnv(key, obj, summary) {
    try {
        await setEnv(appConfig.uzTag, key, JSON.stringify(obj), summary || '')
    } catch (e) {}
}

async function trimLocks(locks) {
    const keys = Object.keys(locks)
    if (keys.length > MAX_LOCK) {
        keys
            .sort((a, b) => (locks[a].t || 0) - (locks[b].t || 0))
            .slice(0, keys.length - MAX_LOCK)
            .forEach((k) => delete locks[k])
    }
    return locks
}

function healthSort(lines, health, order) {
    const score = (n) => {
        const h = health[n]
        if (!h) return 0.5
        const ok = h.ok || 0
        const fail = h.fail || 0
        if (ok + fail === 0) return 0.5
        return ok / (ok + fail)
    }
    const ord = (n) => {
        const i = (order || []).indexOf(n)
        return i < 0 ? 999 : i
    }
    return lines.slice().sort((a, b) => ord(a.name) - ord(b.name) || score(b.name) - score(a.name))
}

async function markHealth(name, ok) {
    if (!name) return
    try {
        const h = await readJsonEnv(HEALTH_KEY)
        const e = h[name] || { ok: 0, fail: 0 }
        if (ok) {
            e.ok = (e.ok || 0) + 1
            e.fail = 0
            e.lf = 0
        } else {
            e.fail = (e.fail || 0) + 1
            e.lf = Date.now()
        }
        h[name] = e
        await writeJsonEnv(HEALTH_KEY, h, '限量版：线路成功率统计')
    } catch (e) {}
}

// 连续失败 2 次且 30 分钟内没恢复的线路直接跳过，避免每次白等超时
function aliveFilter(lines, health) {
    const now = Date.now()
    const alive = lines.filter((x) => {
        const h = health[x.name]
        if (!h) return true
        if ((h.fail || 0) >= 2 && h.lf && now - h.lf < 30 * 60 * 1000) return false
        return true
    })
    return alive.length > 0 ? alive : lines
}

// ============ 弹幕清洗 ============
function isLowQuality(c) {
    if (c.length <= 1) return true
    if (/^[0-9\W_]+$/.test(c)) return true
    if (/^[\W_]+$/.test(c)) return true
    // 纯无意义拉丁字母串（不含中文、无空格、无元音组合感）
    if (/^[a-z]{2,6}$/i.test(c) && !/[aeiou]{2}|ing|tion/i.test(c)) return true
    if (/(.)\1{5,}/.test(c)) return true
    if (/^(aaa|sss|666|2333|\.\.\.|。。。+)$/i.test(c)) return true
    return false
}

function spamKey(c) {
    return c
        .toLowerCase()
        .replace(/[\s\p{P}]/gu, '')
        .replace(/(.)\1+/g, '$1')
}

function downsample(list, max) {
    if (list.length <= max) return list
    const colored = list.filter((d) => d.color && String(d.color) !== '16777215')
    const normal = list.filter((d) => !(d.color && String(d.color) !== '16777215'))
    const keepColored = Math.min(colored.length, Math.floor(max * 0.4))
    const stepC = colored.length / Math.max(1, keepColored)
    const pickC = []
    for (let i = 0; i < keepColored; i++) pickC.push(colored[Math.floor(i * stepC)])
    const rest = max - pickC.length
    const stepN = normal.length / Math.max(1, rest)
    const pickN = []
    for (let i = 0; i < rest; i++) pickN.push(normal[Math.floor(i * stepN)])
    return pickC.concat(pickN)
}

function cleanDanmu(list, cfg, labelName) {
    const out = []
    const seen = {}
    const lastSpam = {}
    for (const d of list) {
        let c = String(d.content || '').replace(/\s+/g, ' ').trim()
        if (!c) continue
        if (c.length > 200) c = c.slice(0, 200)
        if (cfg.lowFilter && isLowQuality(c)) continue
        let blocked = false
        for (const w of cfg.block.concat(cfg.spoiler)) {
            if (w && c.indexOf(w) !== -1) {
                blocked = true
                break
            }
        }
        if (!blocked) {
            for (const re of cfg.regBlock) {
                if (re.test(c)) {
                    blocked = true
                    break
                }
            }
        }
        if (blocked) continue
        if (/^https?:\/\//i.test(c) || /^www\./i.test(c)) continue

        let t = Number(d.time) || 0
        if (cfg.timeOff) t = Math.max(0, t + cfg.timeOff)
        if (cfg.clip && (t < cfg.clip[0] || t > cfg.clip[1])) continue

        const key = c + '@' + Math.round(t)
        if (seen[key]) continue
        seen[key] = 1

        // 刷屏抑制：同内容（去标点/叠字归一）窗口内只留 1 条；严格模式 60s，标准 20s
        const sp = spamKey(c)
        const win = cfg.strongDedup ? 60 : 20
        if (lastSpam[sp] !== undefined && Math.abs(t - lastSpam[sp]) < win) continue
        lastSpam[sp] = t

        const dm = new DanMu()
        dm.content = cfg.label && labelName ? '[' + labelName + '] ' + c : c
        dm.time = t
        dm.color = d.color
        out.push(dm)
    }
    out.sort((a, b) => a.time - b.time)
    return downsample(out, cfg.max).sort((a, b) => a.time - b.time)
}

// ============ 解析 & 请求 ============
function parseDanmuData(data) {
    const out = []
    if (!data) return out
    let text = typeof data === 'string' ? data.trim() : ''
    if (text.length === 0) {
        try {
            text = JSON.stringify(data)
        } catch (e) {
            return out
        }
    }
    try {
        if (text.indexOf('<d p=') >= 0) {
            const $ = cheerio.load(text, { xmlMode: true })
            $('d').each((_, el) => {
                const p = $(el).attr('p')
                const content = $(el).text().trim()
                if (p && content) {
                    const dm = new DanMu()
                    dm.time = parseFloat(p.split(',')[0]) || 0
                    dm.content = content
                    out.push(dm)
                }
            })
            return out
        }
        const j = JSON.parse(text)
        const comments = (j && j.comments) || []
        if (Array.isArray(comments)) {
            comments.forEach((c) => {
                const dm = new DanMu()
                dm.content = c.m || c.message || ''
                dm.time = parseFloat(String(c.p || '0').split(',')[0]) || 0
                dm.color = String(c.p || '').split(',')[2] || '16777215'
                if (dm.content) out.push(dm)
            })
            if (out.length > 0) return out
        }
        const old = (j && j.danmuku) || []
        if (Array.isArray(old)) {
            old.forEach((it) => {
                if (Array.isArray(it) && it.length >= 5) {
                    const dm = new DanMu()
                    dm.time = Number(it[0]) || 0
                    dm.content = String(it[4] || '')
                    dm.color = String(it[2] || '16777215')
                    if (dm.content) out.push(dm)
                }
            })
        }
    } catch (e) {}
    return out
}

function joinPath(base, path) {
    if (base.indexOf('?path=') >= 0) return base + encodeURIComponent(path)
    return base + path
}

async function tryReq(url, timeout) {
    for (let i = 0; i < 2; i++) {
        try {
            const r = await req(url, { responseType: ReqResponseType.plain, timeout: timeout || 12000 })
            if (r && r.data) return r.data
        } catch (e) {}
    }
    return ''
}

// 同一线路可能有两种协议风格：豆儿 /api/v1 风格（/search/episodes）与弹弹Play /v2 风格
function pathVariants(path) {
    const out = []
    if (path.startsWith('/v2/')) {
        out.push(path) // 弹弹Play 原生
        out.push(path.replace('/v2/', '/')) // 豆儿风格
        out.push(path.replace('/v2/', '/api/v2/'))
    } else if (path.startsWith('/api/v2/')) {
        out.push(path)
        out.push(path.replace('/api/v2/', '/v2/'))
        out.push(path.replace('/api/v2/', '/'))
    } else {
        out.push(path)
        out.push('/v2' + path)
    }
    return out
}

async function tryPaths(base, path, timeout) {
    const paths = pathVariants(path)
    for (let i = 0; i < paths.length; i++) {
        const p = paths[i]
        const u = base.indexOf('?path=') >= 0 ? joinPath(base, '/v2' + (p.startsWith('/v2/') ? p.slice(3) : p)) : base.replace(/\/+$/, '') + p
        const raw = await tryReq(u, i === 0 ? timeout : Math.min(4000, timeout))
        if (raw && raw.length > 2) {
            if (raw.trim()[0] === '<') continue // 返回 HTML 说明路径不对
            return raw
        }
    }
    return ''
}

async function commentByUrl(base, videoUrl, timeout) {
    const q = '?url=' + encodeURIComponent(videoUrl)
    const urls = [
        joinPathIfGateway(base, '/v2/comment' + q + '&format=json'),
        joinPathIfGateway(base, '/v2/extcomment' + q),
        joinPathIfGateway(base, '/comment' + q)
    ]
    for (const u of urls) {
        const list = parseDanmuData(await tryReq(u, timeout))
        if (list.length > 0) return list
    }
    return []
}

function joinPathIfGateway(base, path) {
    if (base.indexOf('?path=') >= 0) return joinPath(base, path)
    return base.replace(/\/+$/, '') + path
}

async function commentByEpisodeId(base, episodeId, timeout) {
    const isCN = kLocale.indexOf('CN') !== -1
    const raw = await tryPaths(base, '/v2/comment/' + episodeId + '?withRelated=true&chConvert=' + (isCN ? '1' : '2'), timeout)
    return parseDanmuData(raw)
}

async function searchEpisodes(base, name, epN, isMovie, timeout) {
    let path = '/v2/search/episodes?anime=' + encodeURIComponent(name)
    if (!isMovie) path += '&episode=' + epN
    const raw = await tryPaths(base, path, timeout)
    if (!raw) return []
    try {
        const j = typeof raw === 'string' ? JSON.parse(raw) : raw
        return (j && j.animes) || []
    } catch (e) {
        return []
    }
}

async function bangumiEpisodes(base, animeId, timeout) {
    const raw = await tryPaths(base, '/v2/bangumi/' + animeId, timeout)
    if (!raw) return []
    try {
        const j = typeof raw === 'string' ? JSON.parse(raw) : raw
        const b = j && j.bangumi
        return b && Array.isArray(b.episodes) ? b.episodes : []
    } catch (e) {
        return []
    }
}

async function plainLine(url, videoUrl, timeout) {
    return parseDanmuData(await tryReq(url + videoUrl, timeout))
}

async function getVideoUrl(args, epN, cfg) {
    if (args.videoUrl && args.videoUrl.startsWith('http')) return args.videoUrl.trim()
    if (!args.name) return ''
    const name = cleanName(args.name) || args.name
    const tasks = caiJi.map(async (site) => {
        try {
            const u = site + '/?ac=detail&wd=' + encodeURIComponent(name) + '&pg=1'
            const raw = await tryReq(u, cfg.timeout)
            if (!raw) return ''
            const j = JSON.parse(raw)
            const list = (j && j.list) || []
            if (list.length === 0) return ''
            // 按片名相似度挑最像的一条（同季优先），避免抓到不相干的片子
            const season = seasonNum(args.name)
            let best = null
            let bestScore = 0
            list.forEach((v) => {
                let sc = similar(v.vod_name, name)
                if (normName(v.vod_name) === normName(name)) sc += 1
                if (season > 0) {
                    const vs = seasonNum(v.vod_name)
                    if (vs === season) sc += 0.5
                    else if (vs > 0 && vs !== season) sc -= 0.5
                }
                if (sc > bestScore) {
                    bestScore = sc
                    best = v
                }
            })
            const video = best && bestScore >= 0.5 ? best : null
            if (!video) return ''
            const groups = String(video.vod_play_url || '').split('$$$')
            for (const g of groups) {
                const eps = g.split('#')
                for (let i = 0; i < eps.length; i++) {
                    const arr = eps[i].split('$')
                    if (arr.length === 2 && i === epN - 1) return arr[1]
                }
            }
            return ''
        } catch (e) {
            return ''
        }
    })
    return (
        (await Promise.race([
            ...tasks.map(async (t) => {
                const r = await t
                if (r) return r
                return new Promise(() => {})
            }),
            new Promise((resolve) => setTimeout(() => resolve(''), Math.max(12000, cfg.timeout)))
        ])) || ''
    )
}

async function runLimited(tasks, conc) {
    const out = []
    let i = 0
    const workers = new Array(Math.min(conc, tasks.length)).fill(0).map(async () => {
        while (i < tasks.length) {
            const idx = i++
            try {
                out[idx] = await tasks[idx]()
            } catch (e) {
                out[idx] = null
            }
        }
    })
    await Promise.all(workers)
    return out.filter((x) => x !== null)
}

// 从候选里挑番剧
function pickAnime(animes, wanted) {
    if (!animes || animes.length === 0) return null
    if (wanted) {
        const hit = animes.find((x) => similar(x.animeTitle, wanted) > 0.6)
        if (hit) return hit
    }
    return animes[0]
}

// 从集列表里挑集
function pickEpisode(eps, epN, isMovie) {
    if (!eps || eps.length === 0) return null
    if (isMovie) return eps[0]
    const byTitle = eps.find((e) => new RegExp('第\\s*' + epN + '\\s*[话集期回]').test(String(e.episodeTitle || '')))
    if (byTitle) return byTitle
    return eps[Math.min(Math.max(epN - 1, 0), eps.length - 1)]
}

// 剧名可能来自站点标题 / 弹幕选择结果 / 别名，统一生成多个键，任一命中即可跟随
function lockKeysFor(args) {
    const keys = []
    const add = (k) => {
        const s = String(k || '').trim()
        if (s && s.length >= 2 && !keys.includes(s)) keys.push(s)
    }
    add(titleKey(args))
    add(cleanName(args.name))
    const noSeason = cleanName(args.name).replace(/第\s*[0-9一二三四五六七八九十]+\s*季/g, '').replace(/[Ss]eason\s*\d{1,2}/gi, '').trim()
    add(noSeason)
    add(normName(noSeason))
    // 视频地址去掉查询串和末尾集号，作为“同一部片”的签名
    if (args.videoUrl && /^http/.test(args.videoUrl)) {
        let u = String(args.videoUrl).split('?')[0].split('#')[0]
        u = u.replace(/[\/_-][0-9]{1,4}(\.[a-z0-9]{2,5})?$/i, '')
        u = u.replace(/[0-9]{1,4}/g, '#')
        add('U:' + u)
    }
    return keys
}

function findLock(locks, args) {
    const keys = lockKeysFor(args)
    for (const k of keys) {
        if (locks[k] && locks[k].animeId) return locks[k]
    }
    // 模糊兜底：站点标题和弹幕番名写法不一致时，按相似度找
    const cur = cleanName(args.name)
    let best = null
    let bestScore = 0.55
    Object.keys(locks).forEach((k) => {
        const rec = locks[k]
        if (!rec || !rec.animeId) return
        const cand = rec.animeTitle || k
        let sc = similar(cand, cur)
        if (cur && cand && (cand.indexOf(cur) >= 0 || cur.indexOf(cand) >= 0)) sc = Math.max(sc, 0.8)
        if (sc > bestScore) {
            bestScore = sc
            best = rec
        }
    })
    return best
}

async function rememberLock(locks, args, data, summary) {
    const rec = {
        line: data.line || '智能',
        animeId: data.animeId || 0,
        animeTitle: cleanName(data.animeTitle) || data.animeTitle || '',
        season: data.season || 0,
        t: Date.now()
    }
    lockKeysFor(args).forEach((k) => {
        locks[k] = rec
    })
    if (!lockKeysFor(args).length) locks[titleKey(args)] = rec
    await writeJsonEnv(LOCK_KEY, await trimLocks(locks), summary)
}

// ============ 对外 ============
// 线路列表必须稳：任何异常都不能让客户端拿不到列表（否则界面上只剩“智能”，没法手动选）
async function getLines() {
    let names = []
    try {
        const cfg = await loadConfig()
        const health = await readJsonEnv(HEALTH_KEY)
        names = ['智能']
            .concat(healthSort(cfg.apiBases, health, cfg.order).map((i) => i.name))
            .concat(healthSort(cfg.urlLines, health, cfg.order).map((i) => i.name))
    } catch (e) {
        names = ['智能', '豆儿', '豆儿备用', '弹弹Play', '虾米', 'DouFun', '弹幕库', '678弹幕']
    }
    const uniq = []
    names.forEach((n) => {
        const s = String(n || '').trim()
        if (s && !uniq.includes(s)) uniq.push(s)
    })
    if (uniq.length === 0) {
        uniq.push('智能', '豆儿', '豆儿备用', '弹弹Play')
    }
    try {
        return formatBackData({ lines: uniq, error: '' })
    } catch (e) {
        return JSON.stringify({ lines: uniq, error: '' })
    }
}

async function searchDanMu(args) {
    const started = Date.now()
    const backData = new BackData()
    try {
        const cfg = await loadConfig()
        let locks = await readJsonEnv(LOCK_KEY)
        if (cfg.clear) {
            locks = {}
            await writeJsonEnv(LOCK_KEY, {}, '限量版：已清除锁定记录')
        }

        const tkey = titleKey(args)
        const baseEp = epNum(args)
        const lookupEp = Math.max(1, baseEp + cfg.epOff - (cfg.ep0 > 0 ? cfg.ep0 - 1 : 0))
        const isMovie = !!args.isMovie
        const season = seasonNum(args.name)
        const manual = args.line && args.line !== '智能'
        const memoKey = tkey + '|' + baseEp + '|' + (args.line || '')
        if (memo[memoKey] && Date.now() - memo[memoKey].t < 600000) {
            backData.data = memo[memoKey].data
            return formatBackData(backData)
        }

        const health = await readJsonEnv(HEALTH_KEY)
        let lock = cfg.follow ? findLock(locks, args) : null
        // 设置里手动指定番剧ID（客户端不支持手动选线路时用这个兜底）
        if (cfg.forceId > 0) {
            lock = { line: (lock && lock.line) || '智能', animeId: cfg.forceId, animeTitle: (lock && lock.animeTitle) || cfg.lockName || '', season: 0, t: Date.now() }
        }
        // 防误跟：锁定番名与当前片名差太多就不沿用
        if (lock && lock.animeTitle && similar(lock.animeTitle, tkey) < 0.3) lock = null

        const chosenLine = manual ? args.line : lock ? lock.line : cfg.lineHint && cfg.lineHint !== '智能' ? cfg.lineHint : '智能'

        let apiBases = healthSort(cfg.apiBases, health, cfg.order)
        let urlLines = healthSort(cfg.urlLines, health, cfg.order)
        if (chosenLine && chosenLine !== '智能') {
            const a = apiBases.filter((x) => x.name === chosenLine)
            const u = urlLines.filter((x) => x.name === chosenLine)
            if (a.length + u.length > 0) {
                apiBases = a
                urlLines = u
            }
        } else {
            const a = aliveFilter(apiBases, health)
            const u = aliveFilter(urlLines, health)
            if (a.length + u.length > 0) {
                apiBases = a
                urlLines = u
            }
        }

        const aliasName = cfg.alias[normName(tkey)] || cfg.alias[normName(args.name)] || ''
        const searchName = cfg.lockName || (lock && lock.animeTitle ? lock.animeTitle : aliasName || tkey || args.name)
        const seasonName = !isMovie && season > 0 && !new RegExp('第\\s*' + season + '\\s*季|[Ss]eason\\s*' + season).test(searchName) ? searchName + ' 第' + season + '季' : searchName

        let collected = []
        let sourceName = ''

        // 1) 锁定跟随：同一部番按集数取（多线路并发，哪条先通用哪条）
        if (lock && lock.animeId && apiBases.length > 0) {
            const jobs = apiBases.map((b) => async () => {
                const eps = await bangumiEpisodes(b.base, lock.animeId, cfg.timeout)
                // 集数不够就别用（否则会错拿最后一集），交给后面按片名搜索补齐
                if (!isMovie && eps.length > 0 && eps.length < lookupEp) return { n: b.name, list: [] }
                const target = pickEpisode(eps, lookupEp, isMovie)
                if (!target || !target.episodeId) return { n: b.name, list: [] }
                const list = await commentByEpisodeId(b.base, target.episodeId, cfg.timeout)
                return { n: b.name, list: list, episodeId: target.episodeId }
            })
            const rs = await runLimited(jobs, cfg.conc)
            const hit = rs.filter((x) => x.list && x.list.length > 0).sort((a, b) => b.list.length - a.list.length)[0]
            if (hit) {
                collected = hit.list
                sourceName = hit.n
                await markHealth(hit.n, true)
            } else {
                rs.forEach((x) => markHealth(x.n, false))
            }
        }

        // 2) 客户端给了视频地址 → 多线路直取（最准最快）
        if (collected.length === 0 && args.videoUrl && args.videoUrl.startsWith('http')) {
            const videoUrl = args.videoUrl.trim()
            const jobs = []
            apiBases.forEach((b) => jobs.push(() => commentByUrl(b.base, videoUrl, cfg.timeout).then((r) => ({ n: b.name, r: r }))))
            urlLines.forEach((l) => jobs.push(() => plainLine(l.url, videoUrl, cfg.timeout).then((r) => ({ n: l.name, r: r }))))
            const rs = await runLimited(jobs, cfg.agg ? cfg.conc : 1)
            let best = null
            rs.forEach((it) => {
                if (it.r && it.r.length > 0) {
                    markHealth(it.n, true)
                    if (!best || it.r.length > best.r.length) best = it
                } else markHealth(it.n, false)
            })
            if (best) {
                collected = best.r
                sourceName = best.n
                if (cfg.agg) {
                    rs.forEach((it) => {
                        if (it !== best && it.r && it.r.length > 0 && it.r.length > best.r.length * 0.5) collected = collected.concat(it.r)
                    })
                }
            }
        }

        // 3) 按片名（含季号）+ 集数搜索（多线路并发，取弹幕最多的那条）
        if (collected.length === 0 && apiBases.length > 0) {
            const names = []
            const add = (s) => {
                const v = cleanName(s)
                if (v && v.length >= 2 && !names.includes(v)) names.push(v)
            }
            add(seasonName)
            add(searchName)
            add(tkey)
            add(aliasName)
            add(args.name)
            const jobs = apiBases.map((b) => async () => {
                for (const nm of names) {
                    const animes = await searchEpisodes(b.base, nm, lookupEp, isMovie, cfg.timeout)
                    if (animes.length === 0) continue
                    const pick = pickAnime(animes, cfg.lockName || (lock && lock.animeTitle) || aliasName || tkey)
                    if (!pick) continue
                    const target = pickEpisode(pick.episodes || [], lookupEp, isMovie)
                    if (!target || !target.episodeId) continue
                    const list = await commentByEpisodeId(b.base, target.episodeId, cfg.timeout)
                    if (list.length > 0) return { n: b.name, list: list, pick: pick }
                }
                return { n: b.name, list: [] }
            })
            const rs = await runLimited(jobs, cfg.conc)
            const hit = rs.filter((x) => x.list && x.list.length > 0).sort((a, b) => b.list.length - a.list.length)[0]
            if (hit) {
                collected = hit.list
                sourceName = hit.n
                await markHealth(hit.n, true)
                await rememberLock(
                    locks,
                    args,
                    {
                        line: chosenLine === '智能' ? hit.n : chosenLine,
                        animeId: hit.pick.animeId,
                        animeTitle: hit.pick.animeTitle,
                        season: season
                    },
                    '限量版：自动记住番剧，切集/换季自动跟随'
                )
            } else {
                rs.forEach((x) => markHealth(x.n, false))
            }
        }

        // 4) 兜底：用采集站拿到视频地址再直取（限时 6 秒，避免卡顿）
        if (collected.length === 0 && apiBases.length > 0) {
            const videoUrl = await getVideoUrl(args, lookupEp, { timeout: 6000 })
            if (videoUrl) {
                const rs = await runLimited(
                    apiBases.map((b) => () => commentByUrl(b.base, videoUrl, cfg.timeout).then((r) => ({ n: b.name, r: r }))),
                    cfg.conc
                )
                const best = rs.filter((it) => it.r && it.r.length > 0).sort((a, b) => b.r.length - a.r.length)[0]
                if (best) {
                    collected = best.r
                    sourceName = best.n
                    await markHealth(best.n, true)
                }
            }
        }

        // 手动选线路 → 立刻锁定（客户端不支持手动选线路时，这段不会触发，不影响自动记忆）
        if (manual) {
            const old = findLock(locks, args) || {}
            await rememberLock(
                locks,
                args,
                { line: args.line, animeId: old.animeId || 0, animeTitle: old.animeTitle || '', season: old.season || season },
                '限量版：记住手动选择的线路，切集自动跟随'
            )
        }

        const clean = cleanDanmu(collected, cfg, sourceName)
        backData.data = clean
        if (clean.length === 0) {
            backData.error = '未找到弹幕'
        } else {
            memo[memoKey] = { t: Date.now(), data: clean }
            const keys = Object.keys(memo)
            if (keys.length > MEMO_MAX) delete memo[keys[0]]
            try {
                const ms = Date.now() - started
                const tag = lock && !manual ? '沿用「' + (lock.animeTitle || tkey) + '」' : sourceName || '自动'
                toast('限量版：' + tag + ' 第' + lookupEp + '集 · ' + clean.length + ' 条 · ' + ms + 'ms', 2)
            } catch (e) {}
        }
    } catch (error) {
        backData.error = error.toString()
    }
    return formatBackData(backData)
}
