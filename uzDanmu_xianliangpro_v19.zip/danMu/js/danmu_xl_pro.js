// ignore
//@name:限量版弹幕Pro
//@version:19
//@remark:基于豆儿弹幕接口协议重写的弹幕扩展。主线：手动选线路可锁定、切集沿同一部番不跳剧、能读自己填的弹幕源、多线路取最全、刷屏与低质过滤、条数上限、时间偏移
//@env:弹幕线路##手动选择的弹幕线路，格式 名称1@地址1;名称2@地址2（分号分隔）；留空=智能。也是客户端记录你手选线路的地方
//@env:豆儿弹幕API##兼容弹弹Play协议的接口，格式 名称1@地址1|名称2@地址2（竖线分隔）。留空用内置线路
//@env:我的弹幕源##你自己加的弹幕源都能放这里：名称@地址 或纯地址，多条用 | 或 ; 或换行分隔
//@env:锁定跟随##1 开启（默认）、0 关闭。开启后手动/自动选中的番剧会沿用下去，切集不跳剧
//@env:屏蔽词##用 | 分隔，命中即丢弃；支持正则写法 /关键词1|关键词2/
//@env:条数上限##单集最多保留多少条，默认 3000
//@env:高级设置##用 ; 分隔：epoff=+1 集数偏移｜ep0=1 站点第1集对应弹幕第1集｜timeoff=2 时间偏移秒｜clip=60-1200 只留该时段｜to=8000 超时毫秒｜id=番剧ID 手动指定
//@env:限量版记忆##扩展自动维护，请勿手动修改；清空=忘记已记住的番剧
//@env:限量版线路状态##扩展自动维护，请勿手动修改
//@order: A01
// ignore

var appConfig = { uzTag: '' }
var LINES_CACHE = null

// ===== 内置线路（按连通性排序：先备用的，连不通的放最后）=====
var BUILTIN_LINES = [
    { name: '豆儿备用', base: 'https://dmk.abai.ccwu.cc/api/v1/abaibai' },
    { name: '弹弹Play', base: 'https://api.danmaku.weebly.app/ddp/v1?path=' },
    { name: '豆儿', base: 'https://dm.qqkart.me' },
]

// 本次运行内判定连不通的线路，避免每次都等超时
var DEAD_LINES = {}

var KEY_MEM = '限量版记忆'
var KEY_STATE = '限量版线路状态'
var MEM_MAX = 30

// ===== 小工具 =====
function isGateway(base) {
    return base.indexOf('?path=') >= 0
}

function trimSlash(s) {
    return String(s).replace(/\/+$/g, '')
}

function joinPath(base, path) {
    if (isGateway(base)) return base + path
    return trimSlash(base) + path
}

function epNumber(args) {
    var n = 0
    var t = String((args && args.episode) || '')
    var m = t.match(/(\d{1,4})/)
    if (m) n = parseInt(m[1], 10)
    if (!n) {
        var m2 = String((args && args.name) || '').match(/第\s*([0-9]{1,4})\s*[集话期]/)
        if (m2) n = parseInt(m2[1], 10)
    }
    return n || 1
}

function seasonNumber(text) {
    var s = String(text || '')
    var m = s.match(/第\s*([0-9一二三四五六七八九十]+)\s*季/)
    if (m) {
        var cn = { 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 }
        return cn[m[1]] || parseInt(m[1], 10) || 0
    }
    var m2 = s.match(/[Ss]eason\s*(\d{1,2})/)
    if (m2) return parseInt(m2[1], 10)
    var m3 = s.match(/[Ss](\d{1,2})[Ee]\d{1,3}/)
    if (m3) return parseInt(m3[1], 10)
    var m4 = s.match(/\b(\d{1,2})\b\s*季/)
    if (m4) return parseInt(m4[1], 10)
    return 0
}

// 片名清洗：去掉清晰度、语言、季集标记等噪音
function cleanTitle(raw) {
    var s = String(raw || '')
    s = s.replace(/\.[a-zA-Z0-9]{2,4}$/g, '')
    s = s.replace(/[（(【\[][^）)】\]]{0,40}[）)】\]]/g, function (x) {
        if (/第\s*[0-9一二三四五六七八九十]+\s*[季集]|[Ss]\d{1,2}[Ee]\d{1,3}/.test(x)) return x
        return ''
    })
    s = s.replace(/第\s*[0-9]{1,4}\s*[集话期回]/g, '')
    s = s.replace(/[Ss]\d{1,2}[Ee]\d{1,3}/g, '')
    s = s.replace(/(国语|粤语|双语|中字|中文字幕|简中|繁中|高清|超清|蓝光|4K|8K|1080P|2160P|720P|60帧|HDR|完整版|未删减|无删减)/gi, '')
    s = s.replace(/[·:：\-—_\s]+$/g, '')
    return s.replace(/\s{2,}/g, ' ').trim()
}

// 用于「是不是同一部番」的归一化名字
function normTitle(raw) {
    var s = cleanTitle(raw).toLowerCase()
    s = s.replace(/[^\u4e00-\u9fa5a-z0-9]/g, '')
    s = s.replace(/\s+/g, '')
    return s
}

// 相似度（字符二元组 Dice 系数）
function similarity(a, b) {
    var x = normTitle(a)
    var y = normTitle(b)
    if (!x || !y) return 0
    if (x === y) return 1
    if (x.indexOf(y) >= 0 || y.indexOf(x) >= 0) return 0.8
    var grams = {}
    var i
    for (i = 0; i < x.length - 1; i++) {
        var g = x.substr(i, 2)
        grams[g] = (grams[g] || 0) + 1
    }
    var hit = 0
    for (i = 0; i < y.length - 1; i++) {
        var g2 = y.substr(i, 2)
        if (grams[g2]) {
            grams[g2]--
            hit++
        }
    }
    var total = x.length - 1 + y.length - 1
    return total > 0 ? (2 * hit) / total : 0
}

function parseJsonEnv(text) {
    try {
        var o = JSON.parse(text || '{}')
        return o && typeof o === 'object' ? o : {}
    } catch (e) {
        return {}
    }
}

// ===== 配置 =====
async function readConfig() {
    var cfg = {
        lines: BUILTIN_LINES.slice(0),
        follow: true,
        blocks: [],
        regBlocks: [],
        max: 3000,
        epOff: 0,
        ep0: 0,
        timeOff: 0,
        timeout: 8000,
        clipStart: -1,
        clipEnd: -1,
        forceId: 0,
        pickLine: '',
    }
    var raw, items, i, item, pos, name, url

    try {
        raw = await getEnv(appConfig.uzTag, '豆儿弹幕API')
        if (raw && raw.trim()) {
            items = raw.split(/[|\n\r]+/)
            for (i = 0; i < items.length; i++) {
                item = items[i].trim()
                if (!item) continue
                pos = item.indexOf('@')
                name = pos > 0 ? item.substring(0, pos).trim() : '线路' + (i + 1)
                url = pos >= 0 ? item.substring(pos + 1).trim() : item
                if (!/^https?:/.test(url)) continue
                cfg.lines.push({ name: name, base: trimSlash(url) })
            }
        }
    } catch (e) {}

    try {
        raw = await getEnv(appConfig.uzTag, '我的弹幕源')
        if (raw && raw.trim()) {
            items = raw.split(/[|;\n\r]+/)
            for (i = 0; i < items.length; i++) {
                item = items[i].trim()
                if (!item) continue
                pos = item.indexOf('@')
                name = pos > 0 ? item.substring(0, pos).trim() : '我的线路' + (i + 1)
                url = pos >= 0 ? item.substring(pos + 1).trim() : item
                url = url.replace(/[，,。\s]+$/g, '')
                if (!/^https?:/.test(url)) continue
                cfg.lines.push({ name: name, base: isGateway(url) ? url : trimSlash(url) })
            }
        }
    } catch (e) {}

    // 客户端 v1.6.60+ 的“弹幕线路”键：既能存用户自填线路（名称@地址;…），也会写入用户手选的线路名
    try {
        raw = String(await getEnv(appConfig.uzTag, '弹幕线路')).trim()
        if (raw) {
            var lp = raw.split(/[;；\n\r]+/)
            for (i = 0; i < lp.length; i++) {
                item = lp[i].trim()
                if (!item) continue
                pos = item.indexOf('@')
                if (pos > 0) {
                    name = item.substring(0, pos).trim()
                    url = item.substring(pos + 1).trim()
                    if (/^https?:/.test(url)) cfg.lines.push({ name: name, base: isGateway(url) ? url : trimSlash(url) })
                } else if (!/^https?:/.test(item) && item.length <= 40) {
                    cfg.pickLine = item
                }
            }
        }
    } catch (e) {}

    try {
        var f = String(await getEnv(appConfig.uzTag, '锁定跟随')).trim()
        if (f === '0' || f.toLowerCase() === 'false') cfg.follow = false
    } catch (e) {}

    try {
        var b = String(await getEnv(appConfig.uzTag, '屏蔽词')).trim()
        if (b) {
            var bs = b.split('|')
            for (i = 0; i < bs.length; i++) {
                var w = bs[i].trim()
                if (!w) continue
                if (w.length > 2 && w.charAt(0) === '/' && w.charAt(w.length - 1) === '/') {
                    try {
                        cfg.regBlocks.push(new RegExp(w.substring(1, w.length - 1), 'i'))
                    } catch (e2) {}
                } else {
                    cfg.blocks.push(w)
                }
            }
        }
    } catch (e) {}

    try {
        var mx = parseInt(String(await getEnv(appConfig.uzTag, '条数上限')).trim(), 10)
        if (mx >= 100) cfg.max = Math.min(20000, mx)
    } catch (e) {}

    try {
        var adv = String(await getEnv(appConfig.uzTag, '高级设置')).trim()
        if (adv) {
            var parts = adv.split(';')
            for (i = 0; i < parts.length; i++) {
                var pair = parts[i]
                var eq = pair.indexOf('=')
                if (eq < 0) continue
                var k = pair.substring(0, eq).trim().toLowerCase()
                var v = pair.substring(eq + 1).trim()
                if (k === 'epoff') cfg.epOff = parseInt(v, 10) || 0
                if (k === 'ep0') cfg.ep0 = parseInt(v, 10) || 0
                if (k === 'timeoff') cfg.timeOff = parseFloat(v) || 0
                if (k === 'to') cfg.timeout = Math.min(20000, Math.max(3000, parseInt(v, 10) || 8000))
                if (k === 'id') cfg.forceId = parseInt(v, 10) || 0
                if (k === 'clip') {
                    var mm = v.split('-')
                    if (mm.length === 2) {
                        cfg.clipStart = parseFloat(mm[0]) || 0
                        cfg.clipEnd = parseFloat(mm[1]) || -1
                    }
                }
            }
        }
    } catch (e) {}

    // 去重：同名线路只留一个
    var seen = {}
    var uniq = []
    for (i = 0; i < cfg.lines.length; i++) {
        var key = cfg.lines[i].name + '|' + cfg.lines[i].base
        if (seen[key]) continue
        seen[key] = 1
        uniq.push(cfg.lines[i])
    }
    cfg.lines = uniq
    try {
        var nm = ['智能']
        for (i = 0; i < cfg.lines.length; i++) {
            var nn = String(cfg.lines[i].name || '').trim()
            if (nn && nm.indexOf(nn) < 0) nm.push(nn)
        }
        LINES_CACHE = nm
    } catch (e) {}
    return cfg
}

// ===== 网络 =====
async function getText(url, timeout) {
    try {
        var res = await withTimeout(req(url), timeout || 7000)
        if (!res) return ''
        var d = res.data
        if (typeof d === 'string') return d
        return JSON.stringify(d)
    } catch (e) {
        return ''
    }
}

// 同一路径按「无前缀」「/v2」「/api/v2」依次尝试（豆儿系接口用无前缀路径）
function pathCandidates(path) {
    var out = []
    if (!path) return out
    if (path.indexOf('/api/v2/') === 0) {
        out.push(path)
        out.push(path.substring(7))
    } else if (path.indexOf('/v2/') === 0) {
        out.push(path)
        out.push(path.substring(3))
    } else {
        out.push(path)
        out.push('/v2' + path)
    }
    return out
}

async function withTimeout(promise, ms) {
    var timer
    var timeout = new Promise(function (resolve) {
        timer = setTimeout(function () {
            resolve(null)
        }, ms)
    })
    try {
        var r = await Promise.race([promise, timeout])
        clearTimeout(timer)
        return r
    } catch (e) {
        clearTimeout(timer)
        return null
    }
}

async function getJsonByPath(base, path, timeout) {
    var deadAt = DEAD_LINES[base]
    if (deadAt && Date.now() - deadAt < 600000) return null
    var cands = pathCandidates(path)
    var anyText = false
    for (var i = 0; i < cands.length; i++) {
        var url = joinPath(base, cands[i])
        var text = await getText(url, timeout)
        if (!text) continue
        var head = text.replace(/^\s+/, '')
        if (head.charAt(0) === '<') {
            anyText = true
            continue
        }
        try {
            var obj = JSON.parse(head)
            if (obj && typeof obj === 'object') return obj
        } catch (e) {}
    }
    if (!anyText) DEAD_LINES[base] = Date.now()
    return null
}

// ===== 弹幕解析 =====
function pushDanmu(list, time, content, color) {
    var t = parseFloat(time)
    if (!(t >= 0)) return
    var c = String(content == null ? '' : content).trim()
    if (!c) return
    var col = parseInt(color, 10)
    if (isNaN(col) || col <= 0) col = 0
    list.push({ content: c, time: t, color: col })
}

// 弹弹Play / 豆儿 风格：{comments:[{p:"秒,模式,字号,颜色,...", m:"内容"}]}
function parseDandan(json) {
    var out = []
    if (!json) return out
    var arr = json.comments
    if (!arr && json.data) arr = json.data.comments
    if (!arr || !arr.length) return out
    for (var i = 0; i < arr.length; i++) {
        var it = arr[i]
        if (!it) continue
        var p = String(it.p || '')
        var parts = p.split(',')
        var time = parts.length ? parts[0] : 0
        var color = parts.length > 3 ? parts[3] : 0
        if (typeof it.m === 'string') pushDanmu(out, time, it.m, color)
        else if (typeof it.content === 'string') pushDanmu(out, it.time, it.content, color)
    }
    return out
}

// B 站风格：[时间, 模式, 字号, 颜色, 内容]
function parseBilibili(json) {
    var out = []
    if (!json) return out
    var arr = json.danmuku || json.danmu || (json.data && json.data.danmuku)
    if (!arr || !arr.length) return out
    for (var i = 0; i < arr.length; i++) {
        var it = arr[i]
        if (!it) continue
        if (it.length >= 5) pushDanmu(out, it[0], it[4], it[3])
        else if (typeof it.content === 'string') pushDanmu(out, it.time, it.content, it.color)
    }
    return out
}

function parseComments(json) {
    var a = parseDandan(json)
    if (a.length) return a
    return parseBilibili(json)
}

// ===== 搜索 / 选集 / 取弹幕 =====
async function searchAnime(base, name, timeout) {
    var q = '/search/episodes?anime=' + encodeURIComponent(name)
    var json = await getJsonByPath(base, q, timeout)
    if (!json) return []
    var arr = json.animes || json.data || []
    if (!arr || !arr.length) return []
    return arr
}

async function bangumiEpisodes(base, animeId, timeout) {
    var json = await getJsonByPath(base, '/bangumi/' + animeId, timeout)
    if (!json) return []
    var arr = json.episodes || (json.bangumi && json.bangumi.episodes) || []
    return arr || []
}

function pickEpisode(episodes, wantEp) {
    if (!episodes || !episodes.length) return null
    var i, e
    var n = parseInt(wantEp, 10) || 1
    // 豆儿/弹弹Play 接口的集序号字段是 episodeIndex（不是 episodeNumber）
    for (i = 0; i < episodes.length; i++) {
        e = episodes[i]
        if (!e) continue
        if (parseInt(e.episodeIndex, 10) === n) return e
    }
    for (i = 0; i < episodes.length; i++) {
        e = episodes[i]
        if (!e) continue
        if (parseInt(e.episodeNumber, 10) === n) return e
    }
    var pats = [new RegExp('第\\s*' + n + '\\s*[话集期回]')]
    for (i = 0; i < episodes.length; i++) {
        e = episodes[i]
        if (!e) continue
        var t = String(e.episodeTitle || '')
        if (pats[0].test(t)) return e
    }
    // 兜底：按顺序取第 n 个
    if (episodes.length >= n) return episodes[n - 1]
    return null
}

function pickAnime(animes, title) {
    if (!animes || !animes.length) return null
    var best = null
    var bestScore = 0
    var seasonNow = seasonNumber(title)
    for (var i = 0; i < animes.length; i++) {
        var a = animes[i]
        if (!a) continue
        var name = String(a.animeTitle || a.name || '')
        var sc = similarity(name, title)
        var seasonHit = seasonNumber(name)
        if (seasonNow > 0 && seasonHit > 0) sc += seasonHit === seasonNow ? 0.25 : -0.1
        if (sc > bestScore) {
            bestScore = sc
            best = a
        }
    }
    if (best && bestScore >= 0.45) return best
    return animes[0] || null
}

async function fetchByEpisodeId(base, episodeId, timeout) {
    var q = '/comment/' + episodeId + '?withRelated=true&chConvert=0'
    var json = await getJsonByPath(base, q, timeout)
    return parseComments(json)
}

async function fetchByVideoUrl(base, videoUrl, timeout) {
    var q = '/comment/by-url?url=' + encodeURIComponent(videoUrl) + '&withRelated=true&chConvert=0'
    var json = await getJsonByPath(base, q, timeout)
    return parseComments(json)
}

// ===== 记忆（跟随同一部番）=====
async function readMemory() {
    var raw = ''
    try {
        raw = await getEnv(appConfig.uzTag, KEY_MEM)
    } catch (e) {
        return {}
    }
    return parseJsonEnv(raw)
}

async function writeMemory(map, note) {
    try {
        var keys = Object.keys(map)
        if (keys.length > MEM_MAX) {
            keys.sort(function (a, b) {
                return (map[a].t || 0) - (map[b].t || 0)
            })
            var drop = keys.length - MEM_MAX
            for (var i = 0; i < drop; i++) delete map[keys[i]]
        }
        await setEnv(appConfig.uzTag, KEY_MEM, JSON.stringify(map))
        if (note) {
            try {
                toast(note)
            } catch (e) {}
        }
    } catch (e) {}
}

function lockKeys(title, videoUrl) {
    var out = [normTitle(title)]
    if (videoUrl) out.push('U:' + String(videoUrl).replace(/https?:/g, '').substring(0, 90))
    return out
}

function findLock(map, title, videoUrl) {
    var keys = lockKeys(title, videoUrl)
    var i
    for (i = 0; i < keys.length; i++) {
        if (map[keys[i]]) return map[keys[i]]
    }
    // 站点改名（如「灵笼」→「灵笼 INCARNATION」）时键名对不上，按相似度找回来
    var nt = normTitle(title)
    var best = null
    var bestScore = 0
    var ks = Object.keys(map)
    for (i = 0; i < ks.length; i++) {
        var k = ks[i]
        if (k.charAt(0) === 'U') continue
        var rec = map[k]
        if (!rec || !rec.t) continue
        var names = []
        if (rec.src) names.push(normTitle(rec.src))
        if (rec.title) names.push(normTitle(rec.title))
        names.push(k)
        var j
        var sc = 0
        for (j = 0; j < names.length; j++) {
            if (!names[j]) continue
            var s = similarity(names[j], nt)
            if (s > sc) sc = s
        }
        if (sc > bestScore) {
            bestScore = sc
            best = rec
        }
    }
    if (best && bestScore >= 0.45) return best
    return null
}

// ===== 清洗 =====
function isSpam(content) {
    var c = String(content)
    var body = c.replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, '')
    if (!body) return true
    if (/^\d{1,6}$/.test(c.replace(/\s/g, ''))) return true
    if (body.length <= 2 && /[a-zA-Z0-9]/.test(body)) return true
    if (/(.)\1{5,}/.test(body)) return true
    return false
}

function shouldBlock(content, cfg) {
    var i
    for (i = 0; i < cfg.blocks.length; i++) {
        if (String(content).indexOf(cfg.blocks[i]) >= 0) return true
    }
    for (i = 0; i < cfg.regBlocks.length; i++) {
        if (cfg.regBlocks[i].test(String(content))) return true
    }
    return false
}

function cleanList(list, cfg) {
    var out = []
    var seen = {}
    var i, d, t
    for (i = 0; i < list.length; i++) {
        d = list[i]
        if (!d) continue
        if (shouldBlock(d.content, cfg)) continue
        if (isSpam(d.content)) continue
        t = d.time + cfg.timeOff
        if (t < 0) continue
        if (cfg.clipStart >= 0 && t < cfg.clipStart) continue
        if (cfg.clipEnd >= 0 && t > cfg.clipEnd) continue
        var sk = String(d.content).replace(/\s/g, '') + '|' + Math.round(t / 2)
        if (seen[sk]) continue
        seen[sk] = 1
        out.push({ content: d.content, time: Math.round(t * 100) / 100, color: d.color || 0 })
    }
    if (out.length > cfg.max) {
        var step = out.length / cfg.max
        var keep = []
        for (i = 0; i < cfg.max; i++) keep.push(out[Math.floor(i * step)])
        out = keep
    }
    return out
}

// ===== 对外：线路列表（同步返回，客户端取列表时不会再卡住/判为不支持）=====
function getLines() {
    var names = ['智能']
    var i
    if (LINES_CACHE && LINES_CACHE.length > 0) {
        for (i = 0; i < LINES_CACHE.length; i++) {
            if (names.indexOf(LINES_CACHE[i]) < 0) names.push(LINES_CACHE[i])
        }
    } else {
        names = ['智能', '豆儿备用', '弹弹Play', '豆儿']
    }
    var out
    try {
        out = formatBackData({ lines: names, error: '' })
    } catch (e2) {
        out = JSON.stringify({ lines: names, error: '' })
    }
    return out
}

// ===== 对外：搜索弹幕 =====
async function searchDanMu(args) {
    var started = Date.now()
    var back = { data: [], error: '' }
    args = args || {}
    var title = String(args.name || '')
    var baseEp = epNumber(args)
    var cfg = await readConfig()
    var lookupEp = baseEp + cfg.epOff - (cfg.ep0 > 0 ? cfg.ep0 - 1 : 0)
    if (lookupEp < 1) lookupEp = 1

    var manualLine = String(args.line || cfg.pickLine || '').trim()
    var useLine = manualLine && manualLine !== '智能' ? manualLine : ''
    var mem = await readMemory()
    var lock = cfg.follow ? findLock(mem, title, args.videoUrl) : null
    if (lock) {
        // 防误跟：拿“当时站点的片名”比，不能拿豆儿的长番名比（会把同番误判成不同）
        var baseName = lock.src || lock.title || ''
        if (baseName && similarity(baseName, title) < 0.35) lock = null
    }
    if (cfg.forceId > 0) {
        lock = { animeId: cfg.forceId, title: title, line: (lock && lock.line) || '', season: seasonNumber(title), t: Date.now() }
    }
    if (!useLine && lock && lock.line) useLine = lock.line

    // 候选线路：优先可用线路，连不通的只在没有别的线路时再试
    var lines = []
    var dead = []
    for (i = 0; i < cfg.lines.length; i++) {
        var ln = cfg.lines[i]
        if (useLine && ln.name !== useLine) continue
        var deadAt = DEAD_LINES[ln.base]
        if (deadAt && Date.now() - deadAt < 600000) {
            dead.push(ln)
            continue
        }
        lines.push(ln)
    }
    if (!lines.length) {
        if (dead.length) lines = dead
        else {
            for (i = 0; i < cfg.lines.length; i++) lines.push(cfg.lines[i])
        }
    }

    var got = null
    var gotSource = ''
    var step

    // ① 已记住番剧：按 animeId 定位同一部番，再取对应集（核心：切集不跳剧）
    if (lock) {
        var lockBase = lock.src || title
        var lockNames = []
        var pushLockName = function (s) {
            var v = cleanTitle(s)
            v = String(v).replace(/\.[A-Za-z0-9]{2,4}$/g, '').trim()
            var cn = v.replace(/[^\u4e00-\u9fa5]/g, '')
            if (cn && cn.length >= 2 && lockNames.indexOf(cn) < 0) lockNames.push(cn)
            if (v && lockNames.indexOf(v) < 0) lockNames.push(v)
        }
        pushLockName(lock.src || '')
        pushLockName(title)
        for (i = 0; i < lines.length; i++) {
            step = lines[i]
            var hitAnime = null
            var ni
            var k
            for (ni = 0; ni < lockNames.length && !hitAnime; ni++) {
                var animes2 = await searchAnime(step.base, lockNames[ni], cfg.timeout)
                for (k = 0; k < animes2.length; k++) {
                    if (parseInt(animes2[k].animeId, 10) === parseInt(lock.animeId, 10)) {
                        hitAnime = animes2[k]
                        break
                    }
                }
            }
            if (!hitAnime && lock.season > 0) {
                for (k = 0; k < animes2.length; k++) {
                    if (seasonNumber(animes2[k].animeTitle) === lock.season && similarity(animes2[k].animeTitle, lockBase) >= 0.4) {
                        hitAnime = animes2[k]
                        break
                    }
                }
            }
            if (!hitAnime) continue
            var epsL = hitAnime.episodes && hitAnime.episodes.length ? hitAnime.episodes : await bangumiEpisodes(step.base, hitAnime.animeId, cfg.timeout)
            var epObj = pickEpisode(epsL, lookupEp)
            if (!epObj || !epObj.episodeId) continue
            var list1 = await fetchByEpisodeId(step.base, epObj.episodeId, cfg.timeout)
            if (list1.length > 0) {
                got = list1
                gotSource = step.name + '·沿用'
                found = { anime: hitAnime, eps: epsL, ep: epObj, line: step.name }
                break
            }
        }
    }

    // ② 客户端给了视频地址：直接按地址取，最准
    if (!got && args.videoUrl && /^https?:/.test(String(args.videoUrl))) {
        for (i = 0; i < lines.length; i++) {
            step = lines[i]
            var list2 = await fetchByVideoUrl(step.base, args.videoUrl, cfg.timeout)
            if (list2.length > 0) {
                got = list2
                gotSource = step.name
                break
            }
        }
    }

    // ③ 按片名搜索 → 选番 → 选集 → 取弹幕
    if (!got) {
        var names = []
        var addName = function (s) {
            var v = cleanTitle(s)
            if (v && v.length >= 2 && names.indexOf(v) < 0) names.push(v)
        }
        addName(title)
        var noSeason = String(title).replace(/第\s*[0-9一二三四五六七八九十]+\s*季/g, '').replace(/[Ss]eason\s*\d{1,2}/gi, '')
        addName(noSeason)
        // 站点标题常带英文后缀（如「灵笼 INCARNATION」），去掉拉丁字母再搜一次
        var cnOnly = noSeason.replace(/[^\u4e00-\u9fa5]/g, '')
        addName(cnOnly)
        if (cnOnly.length > 4) addName(cnOnly.substring(0, 4))

        var found = null
        var foundLine = ''
        for (i = 0; i < lines.length; i++) {
            step = lines[i]
            for (var j = 0; j < names.length; j++) {
                var animes = await searchAnime(step.base, names[j], cfg.timeout)
                if (!animes.length) continue
                var anime = pickAnime(animes, title)
                // 有锁时只认同一季，绝不跨季抓弹幕
                if (anime && lock && lock.season > 0 && seasonNumber(anime.animeTitle) !== lock.season) {
                    var sameSeason = null
                    for (var q = 0; q < animes.length; q++) {
                        if (seasonNumber(animes[q].animeTitle) === lock.season) {
                            if (!sameSeason || similarity(animes[q].animeTitle, title) > similarity(sameSeason.animeTitle, title)) sameSeason = animes[q]
                        }
                    }
                    anime = sameSeason
                }
                if (!anime || !anime.animeId) continue
                var eps2 = anime.episodes && anime.episodes.length ? anime.episodes : await bangumiEpisodes(step.base, anime.animeId, cfg.timeout)
                var epObj2 = pickEpisode(eps2, lookupEp)
                if (!epObj2 || !epObj2.episodeId) continue
                var list3 = await fetchByEpisodeId(step.base, epObj2.episodeId, cfg.timeout)
                if (list3.length > 0) {
                    found = { list: list3, anime: anime, line: step.name, eps: eps2, ep: epObj2 }
                    foundLine = step.name
                    break
                }
            }
            if (found) break
        }
        if (found) {
            got = found.list
            gotSource = foundLine
        }
    }

    try {
        if (got && got.length > 0) {
            var clean = cleanList(got, cfg)
            back.data = clean
            // 记住这部番（手动选的线路也一并记住）
            if (cfg.follow) {
                var animeId = found ? parseInt(found.anime.animeId, 10) : lock && lock.animeId ? lock.animeId : 0
                var rec = {
                    animeId: animeId || 0,
                    title: found ? String(found.anime.animeTitle || title) : String(lock && lock.title ? lock.title : title),
                    src: cleanTitle(title),
                    line: useLine || gotSource.replace('·沿用', ''),
                    season: seasonNumber(found ? found.anime.animeTitle : title),
                    t: Date.now(),
                }
                var keys = lockKeys(title, args.videoUrl)
                for (i = 0; i < keys.length; i++) mem[keys[i]] = rec
                await writeMemory(mem, '')
            }
            var ms = Date.now() - started
            try {
                toast('限量版：' + (gotSource || '自动') + ' 第' + lookupEp + '集 · ' + clean.length + ' 条 · ' + ms + 'ms')
            } catch (e3) {}
        } else {
            back.error = '未找到弹幕'
        }
    } catch (e) {
        back.error = String(e)
    }
    return formatBackData(back)
}
