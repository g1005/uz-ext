// ignore
//@name:自定义弹幕扩展·修复版
//@version:1
//@remark:替代已停更的自定义弹幕扩展(v22)。默认走弹弹Play协议，可填自己的 danmu_api 地址；v1.6.60 及以上可用
//@env:弹幕接口地址##格式 名称1@地址1;名称2@地址2。地址填 danmu_api 根地址（如 http://127.0.0.1:9321），或填 ?ac=dm&url= 型线路（如 https://dmku.hls.one/?ac=dm&url=）
//@order: A01
// ignore

import {} from '../../core/uz3lib.js'
import {} from '../../core/uzUtils.js'

const appConfig = {
    _uzTag: '',
    get uzTag() {
        return this._uzTag
    },
    set uzTag(value) {
        this._uzTag = value
    },
}

class DanMu {
    constructor() {
        this.content = ''
        this.time = 0
    }
}

class BackData {
    constructor() {
        this.data = []
        this.error = ''
    }
}

// 默认线路：?ac=dm&url= 型（把视频地址拼在后面的那种）
var builtinUrlLines = [
    { name: '虾米', url: 'https://dmku.hls.one/?ac=dm&url=' },
    { name: 'DouFun', url: 'https://danmu.56uxi.com/?ac=dm&url=' },
    { name: '弹幕库', url: 'https://api.danmu.icu/?ac=dm&url=' },
    { name: '678弹幕', url: 'https://se.678.ooo/?ac=dm&url=' },
]

// 默认接口：兼容弹弹Play协议的公开接口
var builtinApiBases = [{ name: 'ddp公开', base: 'https://api.danmaku.weeblify.app/ddp/v1?path=' }]

var caiJi = ['https://zy.xmm.hk/api.php/provide/vod', 'https://www.69mu.cn/api.php/provide/vod']

function isUrlLine(u) {
    return /[?&]ac=dm|url=$/.test(u)
}

/**
 * 解析用户填写的线路
 */
async function loadLines() {
    let lines = {
        urlLines: builtinUrlLines.slice(),
        apiBases: builtinApiBases.slice(),
    }
    try {
        const raw = await getEnv(appConfig.uzTag, '弹幕接口地址')
        if (raw && raw.length > 0) {
            raw
                .split(';')
                .map((s) => s.trim())
                .filter((s) => s.length > 0)
                .forEach((item, index) => {
                    let name = '线路' + (index + 1)
                    let url = item
                    const pos = item.indexOf('@')
                    if (pos > 0) {
                        name = item.slice(0, pos).trim()
                        url = item.slice(pos + 1).trim()
                    }
                    if (!url || !url.startsWith('http')) return
                    if (isUrlLine(url)) {
                        lines.urlLines.push({ name: name, url: url })
                    } else {
                        lines.apiBases.push({ name: name, base: url.replace(/\/+$/, '') })
                    }
                })
        }
    } catch (e) {}
    return lines
}

/**
 * 可选：返回线路名列表，供 app 里选择
 */
async function getLines() {
    const lines = await loadLines()
    const names = lines.apiBases.map((i) => i.name).concat(lines.urlLines.map((i) => i.name))
    return formatBackData({ lines: ['智能'].concat(names), error: '' })
}

/**
 * 搜索弹幕
 * @param {{name:string, episode:string, videoUrl:string, line:string}} args
 */
async function searchDanMu(args) {
    const backData = new BackData()
    try {
        const lines = await loadLines()
        let urlLines = lines.urlLines
        let apiBases = lines.apiBases

        if (args.line && args.line !== '智能') {
            const keep = (x) => x.name === args.line
            const u = urlLines.filter(keep)
            const a = apiBases.filter(keep)
            if (u.length + a.length > 0) {
                urlLines = u
                apiBases = a
            }
        }

        const videoUrl = await getVideoUrl(args)
        const tasks = []

        // 1) 接口型：直接按视频地址取弹幕（danmu_api 支持）
        if (videoUrl) {
            apiBases.forEach((b) => {
                tasks.push(requestCommentByUrl(b.base, videoUrl))
            })
            urlLines.forEach((l) => {
                tasks.push(requestPlainLine(l.url + videoUrl))
            })
        }

        // 2) 接口型：按片名+集数搜索
        if (args.name) {
            apiBases.forEach((b) => {
                tasks.push(requestCommentByName(b.base, args.name, args.episode, args.isMovie))
            })
        }

        const results = await Promise.all(tasks.map((p) => p.catch(() => [])))
        let picked = []
        for (const r of results) {
            if (r && r.length > 0) {
                picked = r
                break
            }
        }
        backData.data = picked
        if (picked.length === 0) backData.error = '未找到弹幕'
    } catch (error) {
        backData.error = error.toString()
    }
    return formatBackData(backData)
}

async function requestCommentByUrl(base, videoUrl) {
    // danmu_api: /api/v2/comment?url=xxx
    try {
        const u = base + '/api/v2/comment?url=' + encodeURIComponent(videoUrl) + '&format=json'
        const res = await req(u, { responseType: ReqResponseType.plain, timeout: 15000 })
        const list = parseDanmuData(res.data)
        if (list.length > 0) return list
    } catch (e) {}
    // 兼容 ddp 网关型 base（?path= 结尾）
    try {
        const u =
            base.indexOf('?path=') >= 0
                ? base + encodeURIComponent('/v2/comment?url=' + videoUrl)
                : base + '/api/v2/extcomment?url=' + encodeURIComponent(videoUrl)
        const res = await req(u, { responseType: ReqResponseType.plain, timeout: 15000 })
        return parseDanmuData(res.data)
    } catch (e) {}
    return []
}

async function requestPlainLine(u) {
    try {
        const res = await req(u, { responseType: ReqResponseType.plain, timeout: 15000 })
        return parseDanmuData(res.data)
    } catch (e) {
        return []
    }
}

async function requestCommentByName(base, name, episode, isMovie) {
    try {
        const ep = isMovie ? '1' : String(episode || 1)
        const searchPath =
            base.indexOf('?path=') >= 0
                ? base + encodeURIComponent('/v2/search/episodes?anime=' + encodeURIComponent(name) + '&episode=' + ep)
                : base + '/api/v2/search/episodes?anime=' + encodeURIComponent(name) + '&episode=' + ep
        const s = await req(searchPath, { responseType: ReqResponseType.plain, timeout: 15000 })
        const sj = typeof s.data === 'string' ? JSON.parse(s.data) : s.data
        const animes = (sj && sj.animes) || []
        if (animes.length === 0) return []
        const eps = (animes[0] && animes[0].episodes) || []
        if (eps.length === 0) return []
        const episodeId = eps[0].episodeId
        if (episodeId === undefined || episodeId === null) return []

        const isSimplified = kLocale.indexOf('CN') !== -1
        const q = '?withRelated=true&chConvert=' + (isSimplified ? '1' : '2')
        const cPath =
            base.indexOf('?path=') >= 0
                ? base + encodeURIComponent('/v2/comment/' + episodeId + q)
                : base + '/api/v2/comment/' + episodeId + q + '&format=json'
        const c = await req(cPath, { responseType: ReqResponseType.plain, timeout: 15000 })
        return parseDanmuData(c.data)
    } catch (e) {
        return []
    }
}

/**
 * 统一解析：弹弹Play JSON / danmu_api JSON / XML
 */
function parseDanmuData(data) {
    const out = []
    if (!data) return out
    let text = typeof data === 'string' ? data.trim() : ''
    if (text.length === 0) {
        try {
            text = JSON.stringify(data)
        } catch (e) {
            return out
        }
    }
    try {
        if (text.indexOf('<d p=') >= 0) {
            const $ = cheerio.load(text, { xmlMode: true })
            $('d').each((_, el) => {
                const p = $(el).attr('p')
                const content = $(el).text().trim()
                if (p && content) {
                    const dm = new DanMu()
                    dm.time = parseFloat(p.split(',')[0]) || 0
                    dm.content = content
                    out.push(dm)
                }
            })
            return out
        }
        const j = JSON.parse(text)
        // 弹弹Play / danmu_api: comments: [{m,p}]
        const comments = (j && j.comments) || []
        if (Array.isArray(comments) && comments.length > 0) {
            comments.forEach((c) => {
                const dm = new DanMu()
                dm.content = c.m || c.message || ''
                dm.time = parseFloat(String(c.p || '0').split(',')[0]) || 0
                if (dm.content) out.push(dm)
            })
            return out
        }
        // 旧格式: danmuku: [[time, mode, color, uid, text]]
        const old = (j && j.danmuku) || []
        if (Array.isArray(old)) {
            old.forEach((it) => {
                if (Array.isArray(it) && it.length >= 5) {
                    const dm = new DanMu()
                    dm.time = Number(it[0]) || 0
                    dm.content = String(it[4] || '')
                    if (dm.content) out.push(dm)
                }
            })
        }
    } catch (e) {}
    return out
}

/**
 * 拿视频播放地址：优先 app 传进来的，没有再用采集站按片名查
 */
async function getVideoUrl(args) {
    if (args.videoUrl && args.videoUrl.startsWith('http')) return args.videoUrl.trim()
    if (!args.name) return ''
    const name = args.name
    const episode = args.episode
    const tasks = caiJi.map(async (site) => {
        try {
            const u = site + '/?ac=detail&wd=' + encodeURIComponent(name) + '&pg=1'
            const res = await req(u, { timeout: 15000 })
            const j = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
            const list = (j && j.list) || []
            if (list.length === 0) return ''
            const video = list.find((v) => v.vod_name === name) || list[0]
            const groups = String(video.vod_play_url || '').split('$$$')
            for (const g of groups) {
                const eps = g.split('#')
                for (const ep of eps) {
                    const arr = ep.split('$')
                    if (arr.length === 2) {
                        if (parseInt(episode) - 1 === eps.indexOf(ep)) return arr[1]
                    }
                }
            }
            return ''
        } catch (e) {
            return ''
        }
    })
    const first = await Promise.race([
        ...tasks.map(async (t) => {
            const r = await t
            if (r) return r
            return new Promise(() => {})
        }),
        new Promise((resolve) => setTimeout(() => resolve(''), 15000)),
    ])
    return first || ''
}
